﻿//let sm = document.getElementsByClassName("oldImg");

//for (let i = 0; i < sm.length; i++) {
//    sm[i].src = "dog.jpg";
//    console.log(' ig . ${i} is chnanged');
//}



//console.dir(document.querySelector("h1"));



//let par = document.createElement('p');
//par.innerText = "hey i am red ";
//document.querySelector('body').append(par);
//par.classList.add('red');

//let div = document.createElement("div");
//let h1 = document.createElement("h1");
//let p1 = document.createElement("p");


//h1.innerText = "i am a div";
//p1.innerText = " me ttoo in p";

//div.append(h1);
//div.append(p1);
//div.classList.add('box');

//document.querySelector("body").append(div);


//let b = document.createElement("button");
//let p = document.createElement("input");
//b.innerText = " Click me";

//document.querySelector("body").append(b);
//document.querySelector("body").append(p);

//b.setAttribute("id" ,"btn");
//p.setAttribute("placeholder", "username");


//let h = document.querySelector("#btn");
//btn.classList.add("sty");


//let b = document.querySelector("button");
//console.dir(b);

//b.onclick = function () {
//    alert("button is clicked");
//}

//// for multiple btns

//let btb = document.querySelectorAll("button");

//for (btn of btb) {
//    btn.addEventListener = ("clic", sayhello);
//    btn.addEventListener = ("clic", sayhello1);
//}
//function sayhello() {
//    console.log("hi");
//}

//function sayhello1() {
//    console.log("hiiiiiiiiiiiiii");
//}

//let b = document.querySelector("button");

//b.addEventListener("click", function () {
//    let h3 = document.querySelector("h3");
//    let getc = getcolor();
//    h3.innerText = getc;
//    let d = document.querySelector("div");
//    d.style.backgroundColor = getc; // Corrected property name
//});

//function getcolor() {
//    let red = Math.floor(Math.random() * 256);
//    let green = Math.floor(Math.random() * 256);
//    let blue = Math.floor(Math.random() * 256);

//    // Corrected template literal
//    let c = `rgb(${red}, ${green}, ${blue})`;
//    return c;
//}



//keyboard event
//let b = document.querySelector("button");

//b.addEventListener("click", function (event) {
//    console.log(event )
//    console.log("clicked")
//});


//let p = document.querySelector("input");

//p.addEventListener("keydown", function (event) {

//    console.log(event);
//});


////form


//let f = document.querySelector("form");


//f.addEventListener("submit", function (event) {

//    event.preventDefault();
//    //console.log("form submitted");

//    let ip = document.querySelector("input");   or this.elements[0];
//    console.log(ip.value);
//})




// change event   ---

///Activity -----------------------------------

//let b = document.querySelector("button");
//let u = document.querySelector("ul");
//let intr = document.querySelector("input");

//b.addEventListener("click", function () {
//    let itm = document.createElement("li");
//    itm.innerText = intr.value;

//    let de = document.createElement("button");
//    de.innerText = "delete";
//    de.classList.add("del");
//    itm.appendChild(de);
//    u.appendChild(itm);
//    intr.value = "";

//    // Add event listener to the delete button
//    de.addEventListener("click", function () {
//        let par = this.parentElement;
//        par.remove();
//    });
//});

//// Add event listeners to existing delete buttons
//let db = document.querySelectorAll(".del");
//db.forEach(function (d) {
//    d.addEventListener("click", function () {
//        let par = this.parentElement;
//        par.remove();
//    });
//});



//let b = document.querySelector("button");
//let u = document.querySelector("ul");
//let intr = document.querySelector("input");

//b.addEventListener("click", function () {

//    let itm = document.createElement("li");
//    itm.innerText = intr.value;

//    let de = document.createElement("button");
//    de.classList.add("del");
//    itm.appendChild(de);
//    u.appendChild(itm);
//    intr.value = "";
//});


//let db = document.querySelectorAll(".del");
//for (d of db) {
//    d.addEventListener("click", function () {
//        let par = this.parentElement;

//        par.remove();
//    })
//}


let gamesq = [];
let usersq = [];

let starte = false;
let level = 0;

let btns = ["yellow", "red", "purple", "grenn"];

let h2 = document.querySelector("h2");

document.addEventListener("keypress", function () {

    if (starte == false) {
        console.log("game started");
        starte = true;

        lup();
    }

});


function btnf(btn) {


    btn.classList.add("flash");

    setTimeout(function () {

        btn.classList.remove("flash");
    } , 250)
}
function lup() {

    level++;
    h2.innerText = `Level ${level}`;


    let r = Math.floor(Math.random() * 3);
    let rc = btns[r];
    let rb = document.querySelector  (`.${rc}`)
    btnf(rb);

}


