﻿
//let inp = document.querySelector('#newtask input');
//let ul = document.querySelector("#tasks")
//document.querySelector("#push").onclick = function () {



//    if (inp.value.length == 0) {
//        alert("Plz enter a task");
//    }
//    else {
//        let itm = document.createElement("span")
//        itm.innerText = inp.value;
//        inp.value = "";

//    }
//}

let vl = document.querySelectorAll(".num");
let i = 5000;

vl.forEach((vs) => {
    let st = 0;
    let endv = parseInt(vs.getAttribute("data-val"));
    let dr = Math.floor(i / endv);
    let counter = setInterval(function () {
        st += 1;
        vs.textContent = st;

        if (st == endv) {
            clearInterval(counter);
        }
    } , dr);
});
