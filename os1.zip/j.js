﻿
let gamesq = [];
let usersq = [];

let starte = false;
let level = 0;

let btns = ["yellow", "red", "purple", "grenn"];

let h2 = document.querySelector("h2");

document.addEventListener("keypress", function () {

    if (starte == false) {
        console.log("game started");
        starte = true;

        lup();
    }

});


function btnf(btn) {


    btn.classList.add("flash");

    setTimeout(function () {

        btn.classList.remove("flash");
    }, 250)
}
function lup() {

    level++;
    h2.innerText = `Level ${level}`;


    let r = Math.floor(Math.random() * 3);
    let rc = btns[r];
    let rb = document.querySelector(`.${rc}`)
    gamesq.push(rc);
    console.log(gamesq);
    btnf(rb);

}

function check() {

    let ind = level - 1;
    if (usersq[ind] == gamesq[ind]) {

        if (usersq.length == gamesq.length) {
            lup();
        }
    }
    else {
        h2.innerText = "game over click t straat";
    }

}

function btnp() {

    let btn = this;
    btnf(btn);

    usercolor = btn.getAttribute("id");
   
    usersq.push[usercolor];

    check(usersq.length-1);

}

let allbtn = document.querySelectorAll(".btn");

for (bt of allbtn) {
    bt.addEventListener("click", btnp);
}

